const Patient = require("../models/Patient");
const Prescription = require("../models/Prescription");
const User = require("../models/User");

exports.createPatient = async (req, res) => {
  const { username, password, name, age } = req.body;

  try {
    const user = await User.create({ username, password, role: "Patient" });
    const patient = await Patient.create({
      user: user._id,
      name,
      age,
      assignedDoctor: req.user._id,
    });

    res.status(201).json(patient);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.getPatients = async (req, res) => {
  try {
    const patients = await Patient.find({
      assignedDoctor: req.user._id,
    })
      .populate("user")
      .populate("prescriptions");
    console.log(patients);
    res.json(patients);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.addPrescription = async (req, res) => {
  const { patientId, medication, dosage } = req.body;

  try {
    const prescription = await Prescription.create({
      patient: patientId,
      doctor: req.user._id,
      medication,
      dosage,
    });

    const patient = await Patient.findById(patientId);
    patient.prescriptions.push(prescription._id);
    await patient.save();

    res.status(201).json(prescription);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.addHistory = async (req, res) => {
  const { patientId, detail } = req.body;

  try {
    const patient = await Patient.findById(patientId);
    patient.history.push({ date: new Date(), detail });
    await patient.save();

    res.status(201).json(patient);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};
