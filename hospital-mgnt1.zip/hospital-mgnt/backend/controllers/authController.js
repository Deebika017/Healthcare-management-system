const jwt = require("jsonwebtoken");
const User = require("../models/User");
const Patient = require("../models/Patient");

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: "30d" });
};

exports.register = async (req, res) => {
  const { username, password, role, name, age, assignedDoctorId } = req.body;

  try {
    const user = await User.create({ username, password, role });

    if (role === "Patient") {
      const patient = await Patient.create({
        user: user._id,
        name,
        age,
        assignedDoctor: assignedDoctorId,
      });
      res.status(201).json({
        _id: user._id,
        username: user.username,
        role: user.role,
        patient: patient._id,
        token: generateToken(user._id),
      });
    } else {
      res.status(201).json({
        _id: user._id,
        username: user.username,
        role: user.role,
        token: generateToken(user._id),
      });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.login = async (req, res) => {
  const { username, password } = req.body;

  const user = await User.findOne({ username });

  if (user && (await user.matchPassword(password))) {
    res.json({
      _id: user._id,
      username: user.username,
      role: user.role,
      token: generateToken(user._id),
    });
  } else {
    res.status(401).json({ message: "Invalid credentials" });
  }
};
