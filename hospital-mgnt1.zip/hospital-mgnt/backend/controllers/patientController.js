const Patient = require("../models/Patient");

exports.getPatientInfo = async (req, res) => {
  try {
    const patient = await Patient.findOne({ user: req.user._id }).populate(
      "prescriptions"
    );
    res.json(patient);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};
