const mongoose = require("mongoose");

const PrescriptionSchema = new mongoose.Schema({
  patient: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Patient",
    required: true,
  },
  doctor: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  medication: { type: String, required: true },
  dosage: { type: String, required: true },
  date: { type: Date, default: Date.now },
});

const Prescription = mongoose.model("Prescription", PrescriptionSchema);

module.exports = Prescription;
