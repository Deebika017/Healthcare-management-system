const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const { roleCheck } = require("../middleware/roleMiddleware");
const { getPatientInfo } = require("../controllers/patientController");

const router = express.Router();

router.get("/info", protect, roleCheck(["Patient"]), getPatientInfo);

module.exports = router;
