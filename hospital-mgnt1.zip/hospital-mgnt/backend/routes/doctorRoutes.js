const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const { roleCheck } = require("../middleware/roleMiddleware");
const {
  createPatient,
  getPatients,
  addPrescription,
  addHistory,
} = require("../controllers/doctorController");

const router = express.Router();

router.post("/patients", protect, roleCheck(["Doctor"]), createPatient);
router.get("/patients", protect, roleCheck(["Doctor"]), getPatients);
router.post("/prescriptions", protect, roleCheck(["Doctor"]), addPrescription);
router.post("/history", protect, roleCheck(["Doctor"]), addHistory);

module.exports = router;
