import React, { useState } from "react";
import api from "../api";

const AddHistory = ({ patientId }) => {
  const [detail, setDetail] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.post("/doctor/history", { patientId, detail });
    setDetail("");
  };

  return (
    <div className="mt-4">
      <h3 className="text-xl font-semibold mb-2">Add History</h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400"
          type="text"
          placeholder="Detail"
          value={detail}
          onChange={(e) => setDetail(e.target.value)}
        />
        <button
          className="px-4 py-2 font-bold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-400"
          type="submit"
        >
          Add
        </button>
      </form>
    </div>
  );
};

export default AddHistory;
