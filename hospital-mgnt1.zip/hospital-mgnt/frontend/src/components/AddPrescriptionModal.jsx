import React, { useState } from "react";
import Modal from "react-modal";
import api from "../api";
import { XMarkIcon } from "@heroicons/react/20/solid";

const AddPrescriptionModal = ({ patient, isOpen, onClose }) => {
  const [medication, setMedication] = useState("");
  const [dosage, setDosage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.post("/doctor/prescriptions", {
      patientId: patient._id,
      medication,
      dosage,
    });
    setMedication("");
    setDosage("");
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onRequestClose={onClose} ariaHideApp={false}>
      <div className="p-4">
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-semibold mb-4">
            Add Prescription for {patient.name}
          </h3>
          <button
            onClick={onClose}
            className="px-4 py-2 font-bold text-white bg-red-600 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-400"
          >
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400"
            type="text"
            placeholder="Medication"
            value={medication}
            onChange={(e) => setMedication(e.target.value)}
          />
          <input
            className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-400"
            type="text"
            placeholder="Dosage"
            value={dosage}
            onChange={(e) => setDosage(e.target.value)}
          />
          <button
            className="px-4 py-2 font-bold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            type="submit"
          >
            Add
          </button>
        </form>
      </div>
    </Modal>
  );
};

export default AddPrescriptionModal;
