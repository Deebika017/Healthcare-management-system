import React, { useState, useEffect } from "react";
import { logout } from "../auth";
import CreatePatient from "./CreatePatient";
import AddPrescriptionModal from "./AddPrescriptionModal";
import AddHistoryModal from "./AddHistoryModal";
import api from "../api";

const Doctor = () => {
  const [patients, setPatients] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [isPrescriptionModalOpen, setPrescriptionModalOpen] = useState(false);
  const [isHistoryModalOpen, setHistoryModalOpen] = useState(false);

  useEffect(() => {
    const fetchPatients = async () => {
      const response = await api.get("/doctor/patients");
      setPatients(response.data);
    };
    fetchPatients();
  }, []);

  const handleLogout = () => {
    logout();
    window.location.reload();
  };

  const openPrescriptionModal = (patient) => {
    setSelectedPatient(patient);
    setPrescriptionModalOpen(true);
  };

  const openHistoryModal = (patient) => {
    setSelectedPatient(patient);
    setHistoryModalOpen(true);
  };

  const closePrescriptionModal = () => {
    setSelectedPatient(null);
    setPrescriptionModalOpen(false);
  };

  const closeHistoryModal = () => {
    setSelectedPatient(null);
    setHistoryModalOpen(false);
  };

  return (
    <div className="flex flex-col items-center min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold mb-4">Doctor Dashboard</h1>
      <button
        onClick={handleLogout}
        className="px-4 py-2 mb-6 font-bold text-white bg-red-600 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-400"
      >
        Logout
      </button>
      <CreatePatient />
      <h2 className="text-2xl font-bold my-4">Patients</h2>
      <ul className="w-full max-w-2xl space-y-4">
        {patients.map((patient) => (
          <li key={patient._id} className="p-4 bg-white rounded-md shadow-md">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-lg font-semibold">{patient.name}</p>
                <p className="text-sm text-gray-600">Age: {patient.age}</p>
              </div>
              <div className="space-x-2">
                <button
                  onClick={() => openPrescriptionModal(patient)}
                  className="px-4 py-2 font-bold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-400"
                >
                  Add Prescription
                </button>
                <button
                  onClick={() => openHistoryModal(patient)}
                  className="px-4 py-2 font-bold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-400"
                >
                  Add History
                </button>
              </div>
            </div>
            <div className="mt-4">
              <h3 className="text-md font-semibold">Prescriptions:</h3>
              <ul className="list-disc list-inside space-y-2">
                {patient.prescriptions.map((prescription) => (
                  <li key={prescription._id}>
                    {prescription.medication} - {prescription.dosage}
                  </li>
                ))}
              </ul>
              <h3 className="text-md font-semibold mt-4">History:</h3>
              <ul className="list-disc list-inside space-y-2">
                {patient.history.map((entry, index) => (
                  <li key={index}>
                    {new Date(entry.date).toLocaleString()}: {entry.detail}
                  </li>
                ))}
              </ul>
            </div>
          </li>
        ))}
      </ul>

      {selectedPatient && (
        <AddPrescriptionModal
          patient={selectedPatient}
          isOpen={isPrescriptionModalOpen}
          onClose={closePrescriptionModal}
        />
      )}
      {selectedPatient && (
        <AddHistoryModal
          patient={selectedPatient}
          isOpen={isHistoryModalOpen}
          onClose={closeHistoryModal}
        />
      )}
    </div>
  );
};

export default Doctor;
