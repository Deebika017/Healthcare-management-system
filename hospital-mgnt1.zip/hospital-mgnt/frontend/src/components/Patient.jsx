import React, { useState, useEffect } from "react";
import { logout } from "../auth";
import api from "../api";

const Patient = () => {
  const [patient, setPatient] = useState(null);

  useEffect(() => {
    const fetchPatient = async () => {
      const response = await api.get("/patient/info");
      setPatient(response.data);
    };
    fetchPatient();
  }, []);

  const handleLogout = () => {
    logout();
    window.location.reload();
  };

  return (
    <div className="flex flex-col items-center min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold mb-4">Patient Dashboard</h1>
      <button
        onClick={handleLogout}
        className="px-4 py-2 mb-6 font-bold text-white bg-red-600 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-400"
      >
        Logout
      </button>
      {patient && (
        <div className="w-full max-w-2xl p-6 bg-white rounded-md shadow-md">
          <h2 className="text-2xl font-bold mb-4">
            {patient.name} - {patient.age}
          </h2>
          <div className="mb-4">
            <h3 className="text-xl font-semibold mb-2">Prescriptions</h3>
            <ul className="list-disc list-inside space-y-2">
              {patient.prescriptions.map((prescription) => (
                <li key={prescription._id}>
                  {prescription.medication} - {prescription.dosage}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">History</h3>
            <ul className="list-disc list-inside space-y-2">
              {patient.history.map((entry, index) => (
                <li key={index}>
                  {new Date(entry.date).toLocaleString()}: {entry.detail}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default Patient;
