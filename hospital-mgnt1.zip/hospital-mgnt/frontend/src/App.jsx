import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Route,
  Navigate,
  Routes,
} from "react-router-dom";
import Auth from "./components/Auth";
import Doctor from "./components/Doctor";
import Patient from "./components/Patient";
import { getRole } from "./auth";

const App = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    setUser(getRole());
  }, []);

  return (
    <Router>
      <Routes>
        <Route
          path="/login"
          element={user ? <Navigate to="/" /> : <Auth setUser={setUser} />}
        ></Route>
        <Route
          path="/doctor"
          element={user === "Doctor" ? <Doctor /> : <Navigate to="/login" />}
        ></Route>
        <Route
          path="/patient"
          element={user === "Patient" ? <Patient /> : <Navigate to="/login" />}
        ></Route>
        <Route
          path="/"
          element={
            user ? (
              <Navigate to={`/${user.toLowerCase()}`} />
            ) : (
              <Navigate to="/login" />
            )
          }
        ></Route>
      </Routes>
    </Router>
  );
};

export default App;
