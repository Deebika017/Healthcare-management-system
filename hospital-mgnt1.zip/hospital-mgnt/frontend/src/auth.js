import api from "./api";

export const login = async (username, password) => {
  const response = await api.post("/auth/login", { username, password });
  localStorage.setItem("token", response.data.token);
  localStorage.setItem("role", response.data.role);
  return response.data;
};

export const register = async (userData) => {
  const response = await api.post("/auth/register", userData);
  localStorage.setItem("token", response.data.token);
  localStorage.setItem("role", response.data.role);
  return response.data;
};

export const logout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("role");
};

export const getRole = () => {
  return localStorage.getItem("role");
};
